package com.ulan.weatherapp_for_15_1j

class Math {

    fun plus (num1 : Int , num2 : Int ) : Int{
        return num1 + num2
    }
    
}