package com.ulan.weatherapp_for_15_1j.data.model

data class AstroDto(
    val sunrise: String,
    val sunset: String
)
