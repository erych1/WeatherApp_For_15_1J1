package com.ulan.weatherapp_for_15_1j.data.model

data class ConditionDto(
    val text: String,
    val icon: String
)
